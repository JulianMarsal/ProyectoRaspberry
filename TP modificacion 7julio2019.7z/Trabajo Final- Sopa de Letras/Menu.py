import PySimpleGUI as sg
import sopadeletras as Sopa
import constantes as const
import configuracion
import comprobacion as ingreso
from importlib import reload
def elegir_foto(temperatura):
    if temperatura<10:
        foto='frio.png'
    elif 10<temperatura<20:
        foto='frio_calido.png'
    elif 20<temperatura<27:
        foto='calido.png'
    elif temperatura>27:
        foto='caluroso.png'
    return foto

layout_menu=[[sg.Text('')],
        [sg.Button('JUGAR!')],
        [sg.Text('')],
        [sg.Button('CONFIGURACION')],
        [sg.Text('')],
        [sg.Button('INGRESO DE PALABRAS')],     
        [sg.Text('')],
        [sg.Button('CERRAR')],
        [sg.Image(filename=elegir_foto(23),background_color=const.COLOR_FONDO)]]     

def Main():
    '''Programa Principal. Ejecuta la ventana principal y llama a las funciones
    correspondendientes para la funcion del juego de sopa de letras.
    Funciones:
        configuracion.py
        sopadeletras.py
        comprobacion.py (ingreso de las palabras)
        '''   
    window_menu=sg.Window('Menú',size=(400,500),background_color=const.COLOR_FONDO,font='Fixedsys',default_button_element_size=(20,2),
                     auto_size_buttons=False,element_padding=(60,0)).Layout(layout_menu)
    while True:
        event,values=window_menu.Read()
        if event is None or event=='CERRAR':
            window_menu.Close()
            break
        if event=='JUGAR!':
            window_menu.Hide()
            Sopa.Main()
            window_menu.UnHide()
        if event=='CONFIGURACION':
            window_menu.Hide()
            configuracion.Main()     
            window_menu.UnHide()
        if event=='INGRESO DE PALABRAS':
            ingreso.main()
if __name__ =='__main__':
    Main()
            
        

