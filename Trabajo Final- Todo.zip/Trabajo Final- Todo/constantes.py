COLOR_BOTON=('white','#e9967a')
COLOR_TEXTO=('white','#ffe4b5')
COLOR_FONDO='#ffe4b5'
TAGS_FUNCIONAL={'NN':'ustantiv','VB':'erb','JJ':'djetiv'}
'''Las constantes usadas en el programa de sopa de letras'''
