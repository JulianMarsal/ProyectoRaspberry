COLOR_BOTON=('white','#e9967a')
TAGS_FUNCIONAL={'NN':'ustantiv','VB':'erb','JJ':'djetiv'}
'''Las constantes usadas en el programa de sopa de letras'''
