import time
import json
import os
from temperatura import datos_sensor

def leer_datos():
    dic_info = datos_sensor()
    dic_info["fecha"]= time.asctime(time.localtime(time.time())) 
    return dic_info

def guardar(info, oficina):
	archivo= open('datos-oficinas.json','r+')
	json_datos=json.load(archivo)
	json_datos[oficina].append(info)
	objeto=json.dumps(json_datos)
	archivo.write(objeto)
	archivo.close

def main():
	  while True:
        time.sleep(300)   #cada 5 minutos, porque la temp no cambia cada 1 etc
        datos= leer_datos()
        guardar(datos,oficina)	#ver tema de la oficina
	
if __name__ == "__main__":
    main()

